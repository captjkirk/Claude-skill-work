# Memory — personal-growth

_Last updated: [setup date]_

## Memory
<!-- Add persistent facts here. They survive across sessions. -->
